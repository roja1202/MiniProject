package com.cts.training.dao;

import java.util.List;

import com.cts.training.bean.VisitorBean;
import com.cts.training.entity.VisitorEntity;

public interface DAO {

	// void update(Object object);
	void saveVisitor(VisitorBean visitorBean);

	String getPassword(String userName);
	
	List<VisitorEntity> getVisitor(String userName);
	VisitorEntity updateVisitorObject(VisitorBean visitorBean);
	boolean changePassword(String userName,String passWord);
	VisitorEntity getVisitor(int visitorId);
	int getId(String userName);

}
